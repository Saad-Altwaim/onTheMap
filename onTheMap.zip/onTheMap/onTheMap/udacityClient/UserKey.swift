//
//  UserProfileResponse.swift
//  onTheMap
//
//  Created by Saad altwaim on 11/16/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation


class UserKey
{
    static var Value = ""
    static var sessionID = ""
    static var ex = ""
    
}
