//
//  UdacityDataModel.swift
//  onTheMap
//
//  Created by Saad altwaim on 11/7/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation

class UdacityDataModel
{
    static var infoList  = [StudentInfoResponse]()
}
