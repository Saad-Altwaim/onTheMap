//
//  UserDataKey.swift
//  onTheMap
//
//  Created by Saad altwaim on 11/17/20.
//  Copyright © 2020 Saad Altwaim. All rights reserved.
//

import Foundation

class UserDataKey
{
    static var DataKeyValue = [UserResponse]()
}
